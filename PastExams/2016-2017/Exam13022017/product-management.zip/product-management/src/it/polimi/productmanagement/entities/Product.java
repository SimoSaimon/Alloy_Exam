package it.polimi.productmanagement.entities;

import java.io.Serializable;
import java.lang.String;

import javax.persistence.*;

@Entity
@Table(name = "Product")
public class Product implements Serializable {

    @Column(nullable = false)
    private String productName;
    
    @Column(nullable = false)
    private Integer quantity = 0;
    
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private static final long serialVersionUID = 1L;

    public Product() {
        super();
    }

    public String getProductName() {
        return this.productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

}

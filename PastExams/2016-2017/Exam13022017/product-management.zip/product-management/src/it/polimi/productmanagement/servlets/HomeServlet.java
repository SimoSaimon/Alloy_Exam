package it.polimi.productmanagement.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.polimi.productmanagement.beans.ProductBean;

public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
    private ProductBean sportEventService;

    public HomeServlet() {
        super();
    }

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String name = req.getParameter("productName");
            String quantity = req.getParameter("quantity");
            if(sportEventService.insertProduct(name, Integer.parseInt(quantity)) != null){
                req.getRequestDispatcher("/home.jsp").forward(req, resp);
            } else {
                req.getRequestDispatcher("/error.jsp").forward(req, resp);
            }
        } catch (IllegalArgumentException e) {
            req.setAttribute("error", e.getMessage());
            req.getRequestDispatcher("/home.jsp").forward(req, resp);
        } 
	}

}

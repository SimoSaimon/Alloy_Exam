package it.polimi.productmanagement.beans;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import it.polimi.productmanagement.entities.Product;

@Stateless
public class ProductBean {

    @PersistenceContext(unitName = "class-example")
    private EntityManager em;
    
    public ProductBean() {

    }
    
    public Product getFromName(String productName) {
        try {
            return (Product) this.em.createQuery("SELECT p FROM Product p WHERE p.productName=:productName")
                    .setParameter("productName", productName).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }
    
    public Product insertProduct(String name, Integer quantity) {
        if (getFromName(name) == null) {
            Product p = new Product();
            p.setProductName(name);
            p.setQuantity(quantity);
            em.persist(p);
            return p;
        } else {
            return null;
        }
    }
    
    public Product updateProductQuantity(String productName, Integer newQuantity) {
        Product toUpdate = getFromName(productName);
        if (toUpdate != null) {
            toUpdate.setQuantity(newQuantity);
            em.persist(toUpdate);
            return toUpdate;
        } else {
            return null;
        }
    }
    
    public List<Product> selectExpiringProducts(Integer quantityLowerBound) {
        List<Product> toReturn = new ArrayList<Product>();
        Product temp;
        Iterator<Product> iter = getProductList().iterator();
        while(iter.hasNext()){
            temp = iter.next();
            if(temp.getQuantity() < quantityLowerBound){
                toReturn.add(temp);
            }
        }
        
        return toReturn;
    }
    
    public List<Product> getProductList() {
        try {
            return (List<Product>) this.em.createQuery("SELECT p FROM Product p").getResultList();
        } catch (NoResultException ex) {
            return new ArrayList<Product>();
        }
    }

}
